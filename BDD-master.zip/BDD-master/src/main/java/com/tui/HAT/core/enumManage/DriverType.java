package com.tui.HAT.core.enumManage;

public enum DriverType {
    INTERNETEXPLORER,
    CHROME,
    CHROME_REMOTE,
    INTERNETEXPLORER_REMOTE

}