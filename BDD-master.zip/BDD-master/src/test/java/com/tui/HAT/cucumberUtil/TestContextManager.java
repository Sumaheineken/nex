package com.tui.HAT.cucumberUtil;


import com.tui.HAT.cucumberUtil.TestContext;
import com.tui.HAT.pageObjects.*;

public class TestContextManager {

    public TestContext testContext;
    public LoginPage loginPage;
public Nex nex;


    public TestContextManager(TestContext context){
        testContext=context;
        loginPage=testContext.getPageObjectManager().getLoginPage();

        nex=testContext.getPageObjectManager().getNex();
    }

}
